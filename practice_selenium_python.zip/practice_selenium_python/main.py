import os
import shutil
import container.variable as vs
import container.exportTask as task
import container.renameFile as rename
import container.writeGoogle as googleSheet

def main():
    link = vs.PATH_FILE_EXPORT
    files = os.listdir(link)
    for file in files:
        shutil.rmtree(f'{link}/{file}')

    task.export_data()
    print('Success')
    rename.rename()
    print('Rename success')
    googleSheet.write_google_sheet()
    print('Google success')
main()
