import os
import time
from selenium import webdriver

import container.variable as vs
from selenium.webdriver.common.by import By

list_name = []
list_link = []
list_ggsheet = []


def getInput():
    file_input = os.listdir('../practice_selenium_python/input')
    for i in range(len(file_input)):
        with open('../practice_selenium_python/input/' + file_input[i]) as f:
            contents = f.readlines()
            for index in range(len(contents)):
                if i == 0:
                    list_ggsheet.append(contents[index].rstrip())
                if i == 1:
                    list_name.append(contents[index].rstrip())
                if i == 2:
                    list_link.append(contents[index].rstrip())

    return [list_name, list_ggsheet, list_link]


def login(path, driver):
    time.sleep(2)
    driver.get(path)

    txt_email = driver.find_element(By.ID, "username")
    txt_email.send_keys(vs.USER_NAME_LOGIN)
    txt_pass = driver.find_element(By.ID, "password")
    txt_pass.send_keys(vs.PASSWORD_USER_LOGIN)

    time.sleep(1)
    btn_submit_fb = driver.find_element(By.XPATH, vs.BUTTON_LOGIN_OP)
    btn_submit_fb.submit()


def export_data_excel_op(driver):
    WORK_PACKAGES_SETTING_BUTTON = driver.find_element(By.ID, vs.ID_WORK_PACKAGES_SETTING_BUTTON)
    time.sleep(1)
    WORK_PACKAGES_SETTING_BUTTON.click()

    time.sleep(1)
    btn_export = driver.find_element(By.XPATH, vs.SETTING_BUTTON_EXPORT)
    btn_export.click()

    time.sleep(1)
    export_file_cls = driver.find_element(By.XPATH, vs.EXPORT_XLS)
    export_file_cls.click()
    time.sleep(5)


def get_chrome_option():
    chrome_options = webdriver.ChromeOptions()
    chrome_options.headless = True
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-dev-shm-usage')
    return chrome_options


def get_driver(project, folderName):
    # chrome_options = webdriver.ChromeOptions()
    chrome_options = get_chrome_option()
    prefs = {'download.default_directory': vs.PATH_FOLDER_SAVE_FILE +
                                           project + folderName}
    chrome_options.add_experimental_option('prefs', prefs)
    return webdriver.Chrome(executable_path=vs.PATH_SELENIUM_CHORM, chrome_options=chrome_options)
