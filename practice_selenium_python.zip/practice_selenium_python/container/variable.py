#Account login open project
USER_NAME_LOGIN = "miichisoft.qa@gmail.com"
PASSWORD_USER_LOGIN = "Miichisoft@0104"

# chrom selenium 99
PATH_SELENIUM_CHORM = "../practice_selenium_python/chorm/chromedriver"
PATH_FILE_EXPORT = '../practice_selenium_python/export_data/'
PATH_FOLDER_SAVE_FILE = '/home/miichi/practice_selenium_python/export_data/'

BUTTON_LOGIN_OP = "/html/body/div[2]/div[2]/div[2]/div[2]/div/form/input[4]"
ID_WORK_PACKAGE = 'main-menu-work-packages'

ID_BUTTON_FILLTER = 'work-packages-filter-toggle-button'
ID_FILLTER_STATUS = 'operators-status'

STATUS_OPTION_ALL = '/html/body/div[2]/div[2]/div[3]/div[2]/openproject-base/div/ui-view/openproject-base/div/ui-view/work-packages-base/div/ui-view/wp-view-page/div/filter-container/div/div/query-filters/fieldset/ul/li[3]/div[1]/select/option[5]'

INPUT_ADD_FILTER = '/html/body/div[2]/div[2]/div[3]/div[2]/openproject-base/div/ui-view/openproject-base/div/ui-view/work-packages-base/div/ui-view/wp-view-page/div/filter-container/div/div/query-filters/fieldset/ul/li[4]/div/ng-select/div/div/div[2]/input'
FILTER_TYPE = '/html/body/ng-dropdown-panel/div/div[2]/div[3]'
LABEL_TYPE = '/html/body/div[2]/div[2]/div[3]/div[2]/openproject-base/div/ui-view/openproject-base/div/ui-view/work-packages-base/div/ui-view/wp-view-page/div/filter-container/div/div/query-filters/fieldset/ul/li[4]/label'
INPUT_FILTER_TYPE = '/html/body/div[2]/div[2]/div[3]/div[2]/openproject-base/div/ui-view/openproject-base/div/ui-view/work-packages-base/div/ui-view/wp-view-page/div/filter-container/div/div/query-filters/fieldset/ul/li[4]/div[2]/filter-toggled-multiselect-value/div/ng-select/div/div/div[2]/input'
OPTION_TYPE_TASK = '/html/body/ng-dropdown-panel/div/div[2]/div'
ID_WORK_PACKAGES_SETTING_BUTTON = 'work-packages-settings-button'

SETTING_INSERT_COLUMN = '/html/body/div[5]/ng-component/div/ul/li[2]/a/span'
INPUT_ADD_COLUMN = '/html/body/div[3]/ng-component/div/div/div[3]/ng-component/div/draggable-autocompleter/div/ng-select/div/div/div[2]/input'
COLUMN_DEFAULT_FIRST = '/html/body/ng-dropdown-panel/div/div[2]/div'
BUTTON_APPLY_ADD_COLUMN = '/html/body/div[3]/ng-component/div/div/div[4]/button[1]'
SETTING_BUTTON_EXPORT = '/html/body/div[5]/ng-component/div/ul/li[9]/a/span'
EXPORT_XLS = '/html/body/div[3]/ng-component/div/div/ul/li[7]'

#fillter internal

CHOOSE_STATUS_OPTION = '/html/body/div[2]/div[2]/div[3]/div[2]/openproject-base/div/ui-view/openproject-base/div/ui-view/work-packages-base/div/ui-view/wp-view-page/div/filter-container/div/div/query-filters/fieldset/ul/li[3]/div[1]/select/option[4]'
INPUT_STATUS_OPTION =  '/html/body/div[2]/div[2]/div[3]/div[2]/openproject-base/div/ui-view/openproject-base/div/ui-view/work-packages-base/div/ui-view/wp-view-page/div/filter-container/div/div/query-filters/fieldset/ul/li[3]/div[2]/filter-toggled-multiselect-value/div/ng-select/div/div/div[2]/input'
INPUT_STATUS_OPTION_TWO = '/html/body/div[2]/div[2]/div[3]/div[2]/openproject-base/div/ui-view/openproject-base/div/ui-view/work-packages-base/div/ui-view/wp-view-page/div/filter-container/div/div/query-filters/fieldset/ul/li[3]/div[2]/filter-toggled-multiselect-value/div/ng-select/div/div/div[3]/input'
OPTION_TYPE_REJECT = '/html/body/ng-dropdown-panel/div/div[2]/div'
OPTION_TYPE_BUG = '/html/body/ng-dropdown-panel/div/div[2]/div[1]'
OPTION_BUG_CAUSE = '/html/body/div[2]/div[2]/div[3]/div[2]/openproject-base/div/ui-view/openproject-base/div/ui-view/work-packages-base/div/ui-view/wp-view-page/div/filter-container/div/div/query-filters/fieldset/ul/li[5]/div[1]/select'
BUG_CAUSE_IS_NOT = '/html/body/div[2]/div[2]/div[3]/div[2]/openproject-base/div/ui-view/openproject-base/div/ui-view/work-packages-base/div/ui-view/wp-view-page/div/filter-container/div/div/query-filters/fieldset/ul/li[5]/div[1]/select/option[2]'
INPUT_BUG_CAUSE_IS_NOT = '/html/body/div[2]/div[2]/div[3]/div[2]/openproject-base/div/ui-view/openproject-base/div/ui-view/work-packages-base/div/ui-view/wp-view-page/div/filter-container/div/div/query-filters/fieldset/ul/li[5]/div[2]/filter-toggled-multiselect-value/div/ng-select/div/div/div[2]/input'
ID_CREATED_ON = 'operators-createdAt'
CREATED_ON_BETWEEN = '/html/body/div[2]/div[2]/div[3]/div[2]/openproject-base/div/ui-view/openproject-base/div/ui-view/work-packages-base/div/ui-view/wp-view-page/div/filter-container/div/div/query-filters/fieldset/ul/li[6]/div[1]/select/option[7]'
ID_BETWEEN_START = 'values-createdAt-begin'
ID_BETWEEN_END = 'values-createdAt-end'


################################

# Status Option Is Not
STATUS_OPTION_IS_NOT = '/html/body/div[2]/div[2]/div[3]/div[' \
                       '2]/openproject-base/div/ui-view/openproject-base/div/ui-view/work-packages-base/div/ui-view' \
                       '/wp-view-page/div/filter-container/div/div/query-filters/fieldset/ul/li[3]/div[' \
                       '1]/select/option[4] '

# Input status
INPUT_STATUS = '/html/body/div[2]/div[2]/div[3]/div[2]/openproject-base/div/ui-view/openproject-base/div/ui-view/work' \
               '-packages-base/div/ui-view/wp-view-page/div/filter-container/div/div/query-filters/fieldset/ul/li[' \
               '3]/div[2]/filter-toggled-multiselect-value/div/ng-select/div/div/div[2]/input '

# Option one
OPTION_ONE = '/html/body/ng-dropdown-panel/div/div[2]/div'

# On hold input status
ON_HOLD_INPUT_STATUS = '/html/body/ng-dropdown-panel/div/div[2]/div[3]'
# Input Add UAT Type
INPUT_ADD_UAT_TYPE = '/html/body/div[2]/div[2]/div[3]/div[' \
                     '2]/openproject-base/div/ui-view/openproject-base/div/ui-view/work-packages-base/div/ui-view/wp' \
                     '-view-page/div/filter-container/div/div/query-filters/fieldset/ul/li[' \
                     '5]/div/ng-select/div/div/div[2]/input '

# Status Option Is Not UAT Type
STATUS_OPTION_IS_NOT_UAT_TYPE = '/html/body/div[2]/div[2]/div[3]/div[' \
                                '2]/openproject-base/div/ui-view/openproject-base/div/ui-view/work-packages-base/div' \
                                '/ui-view' \
                                '/wp-view-page/div/filter-container/div/div/query-filters/fieldset/ul/li[5]/div[' \
                                '1]/select/option[2] '

# Input UAT Type
INPUT_UAT_TYPE = '/html/body/div[2]/div[2]/div[3]/div[2]/openproject-base/div/ui-view/openproject-base/div/ui-view' \
                 '/work-packages-base/div/ui-view/wp-view-page/div/filter-container/div/div/query-filters/fieldset/ul' \
                 '/li[5]/div[2]/filter-toggled-multiselect-value/div/ng-select/div/div/div[2]/input '

# Created On
CREATED_ON = '/html/body/div[2]/div[2]/div[3]/div[2]/openproject-base/div/ui-view/openproject-base/div/ui-view/work' \
             '-packages-base/div/ui-view/wp-view-page/div/filter-container/div/div/query-filters/fieldset/ul/li[' \
             '6]/div/ng-select/div/div/div[2]/input '

# Status Option Created on
STATUS_OPTION_CREATED_ON = '/html/body/div[2]/div[2]/div[3]/div[' \
                           '2]/openproject-base/div/ui-view/openproject-base/div/ui-view/work-packages-base/div/ui' \
                           '-view/wp-view-page/div/filter-container/div/div/query-filters/fieldset/ul/li[6]/div[' \
                           '1]/select/option[7] '
# remover configuration view
REMOVE_CONFIGURATION = '/html/body/div[3]/ng-component/div/div/div[' \
                       '3]/ng-component/div/draggable-autocompleter/div/div/div[6]/a '
OPTION_ASSIGNEE = '/html/body/div[3]/ng-component/div/div/div[3]/ng-component/div/draggable-autocompleter/div/div/div[5]/a'
OPTION_STATUS = '/html/body/div[3]/ng-component/div/div/div[3]/ng-component/div/draggable-autocompleter/div/div/div[4]/a'
#############################################
