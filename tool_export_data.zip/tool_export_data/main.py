import os
import time
import shutil

link = '../practice_selenium_python/export_data'
files = os.listdir(link)

for file in files:
    shutil.rmtree(f'{link}/{file}')

os.system('python3 ../practice_selenium_python/container/exportTask.py')
print('Task success')
time.sleep(10)
os.system('python3 ../practice_selenium_python/container/exportInternal.py')
print('Internal success')
time.sleep(10)
os.system('python3 ../practice_selenium_python/container/exportUAT.py')
print('UAT success')
time.sleep(2)
os.system('python3 ../practice_selenium_python/container/renameFile.py')
print('Rename success')
time.sleep(4)
os.system('python3 ../practice_selenium_python/container/writeGoogle.py')
print('Google success')
