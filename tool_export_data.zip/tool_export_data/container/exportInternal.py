from selenium.webdriver.common.by import By
import time
from selenium import webdriver
from datetime import date, timedelta
import os
import variable as vs
from os.path import exists
import helper as hp

chrome_options = webdriver.ChromeOptions()
chrome_options.headless = True
chrome_options.add_argument('--no-sandbox')
chrome_options.add_argument('--disable-dev-shm-usage')

today = str(date.today())
subToday = str(date.today() - timedelta(days=7))

def login(path):
    time.sleep(1)
    driver.get(path)

    txt_email = driver.find_element(By.ID, "username")
    txt_email.send_keys(vs.USER_NAME_LOGIN)
    txt_pass = driver.find_element(By.ID, "password")
    txt_pass.send_keys(vs.PASSWORD_USER_LOGIN)

    time.sleep(1)
    btn_submit_fb = driver.find_element(By.XPATH, vs.BUTTON_LOGIN_OP)
    btn_submit_fb.submit()

def main(path, subToday):
    time.sleep(1)
    driver.get(path)
    time.sleep(2)
    WORK_PACKAGES = driver.find_element(By.ID, vs.ID_WORK_PACKAGE)
    WORK_PACKAGES.click()

    def filter_op():
        # FILTER
        time.sleep(1)
        button_filter = driver.find_element(By.ID, vs.ID_BUTTON_FILLTER)
        button_filter.click()

        time.sleep(2)
        filter_option_status = driver.find_element(By.ID, vs.ID_FILLTER_STATUS)
        filter_option_status.click()

        time.sleep(2)
        choose_status = driver.find_element(By.XPATH, vs.CHOOSE_STATUS_OPTION)
        choose_status.click()

        time.sleep(2)
        input_add_filter = driver.find_element(By.XPATH, vs.INPUT_ADD_FILTER)
        input_add_filter.send_keys('type')

        time.sleep(2)
        add_filler_type = driver.find_element(By.XPATH, vs.FILTER_TYPE)
        add_filler_type.click()

        time.sleep(2)
        driver.find_element(By.XPATH, vs.INPUT_STATUS_OPTION).send_keys('on')
        time.sleep(2)
        label_type = driver.find_element(By.XPATH, vs.LABEL_TYPE)
        time.sleep(2)
        choose_status_on_hold = driver.find_element(By.XPATH, vs.FILTER_TYPE)
        choose_status_on_hold.click()
        time.sleep(2)
        label_type.click()
        time.sleep(2)
        driver.find_element(By.XPATH, vs.INPUT_STATUS_OPTION_TWO).send_keys('rejected')
        time.sleep(2)
        choose_status_reject = driver.find_element(By.XPATH, vs.OPTION_TYPE_REJECT)
        choose_status_reject.click()
        time.sleep(1)
        label_type.click()

        time.sleep(1)
        input_add_filter.send_keys('Bug Cause')

        time.sleep(2)
        add_filler_bug_cause = driver.find_element(By.XPATH, vs.OPTION_TYPE_TASK)
        add_filler_bug_cause.click()

        time.sleep(2)
        driver.find_element(By.XPATH, vs.INPUT_FILTER_TYPE).send_keys('bug')

        time.sleep(2)
        choose_type_bug = driver.find_element(By.XPATH, vs.OPTION_TYPE_BUG)
        choose_type_bug.click()

        time.sleep(1)
        option_bug_cause = driver.find_element(By.XPATH, vs.OPTION_BUG_CAUSE).click()
        time.sleep(1)
        choose_bug_cause_is_not = driver.find_element(By.XPATH, vs.BUG_CAUSE_IS_NOT).click()
        time.sleep(1)
        input_bug_cause_is_not = driver.find_element(By.XPATH, vs.INPUT_BUG_CAUSE_IS_NOT).click()
        time.sleep(1)
        choose_bug_cause_spec = driver.find_element(By.XPATH, vs.FILTER_TYPE).click()
        time.sleep(1)
        label_type.click()
        time.sleep(1)
        input_add_filter.send_keys('Created on')
        time.sleep(1)
        add_filler_created_on = driver.find_element(By.XPATH, vs.OPTION_TYPE_TASK).click()
        time.sleep(1)
        option_created_on = driver.find_element(By.ID, vs.ID_CREATED_ON).click()
        time.sleep(1)
        choose_created_on_between = driver.find_element(By.XPATH, vs.CREATED_ON_BETWEEN).click()
        time.sleep(1)
        created_on_between_start = driver.find_element(By.ID, vs.ID_BETWEEN_START).send_keys(subToday)
        time.sleep(1)
        created_on_between_end = driver.find_element(By.ID, vs.ID_BETWEEN_END).send_keys(today)

    filter_op()
    time.sleep(1)
    WORK_PACKAGES_SETTING_BUTTON = driver.find_element(By.ID, vs.ID_WORK_PACKAGES_SETTING_BUTTON)

    def insertColumns():
        time.sleep(2)
        work_packages_settings_button = driver.find_element(By.ID, 'work-packages-settings-button')
        work_packages_settings_button.click()

        time.sleep(2)
        setting_insert_column = driver.find_element(By.XPATH, vs.SETTING_INSERT_COLUMN).click()

        time.sleep(2)
        delete_option_version = driver.find_element(By.XPATH, '/html/body/div[3]/ng-component/div/div/div[3]/ng-component/div/draggable-autocompleter/div/div/div[6]/a')
        delete_option_version.click()

        time.sleep(2)
        delete_option_assignee = driver.find_element(By.XPATH, '/html/body/div[3]/ng-component/div/div/div[3]/ng-component/div/draggable-autocompleter/div/div/div[5]/a')
        delete_option_assignee.click()

        time.sleep(2)
        delete_option_status = driver.find_element(By.XPATH, '/html/body/div[3]/ng-component/div/div/div[3]/ng-component/div/draggable-autocompleter/div/div/div[4]/a')
        delete_option_status.click()

        time.sleep(2)
        input_add_column = driver.find_element(By.XPATH, vs.INPUT_ADD_COLUMN)
        input_add_column.send_keys('Category')
        time.sleep(1)
        add_column_category = driver.find_element(By.XPATH, vs.OPTION_TYPE_TASK).click()

        time.sleep(2)
        input_add_column.send_keys('Status')
        add_column_status = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST).click()

        time.sleep(2)
        input_add_column.send_keys('Assignee')
        add_column_assignee = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST).click()

        time.sleep(2)
        input_add_column.send_keys('Author')
        add_column_author = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST).click()

        time.sleep(2)
        input_add_column.send_keys('Bug Severity')
        add_column_Bug_severity = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST).click()

        time.sleep(2)
        input_add_column.send_keys('Bug Type')
        add_column_Bug_type = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST).click()

        time.sleep(2)
        input_add_column.send_keys('Bug Cause')
        add_column_Bug_cause = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST).click()

        time.sleep(2)
        input_add_column.send_keys('Bug Ui')
        add_column_Bug_Ui = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST).click()

        time.sleep(2)
        input_add_column.send_keys('Created on')
        add_column_created_on = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST).click()

        time.sleep(2)
        input_add_column.send_keys('Accountable')
        add_column_Accountable = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST).click()

        time.sleep(2)
        input_add_column.send_keys('UAT')
        add_column_UAT = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST).click()

        time.sleep(2)
        input_add_column.send_keys('Updated on')
        add_column_updated_on = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST).click()

        time.sleep(2)
        input_add_column.send_keys('Version')
        add_column_version = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST).click()

        time.sleep(2)
        input_add_column.send_keys('Spent time')
        time.sleep(1)
        add_column_spent_time = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST).click()
        time.sleep(2)
        btn_apply = driver.find_element(By.XPATH, vs.BUTTON_APPLY_ADD_COLUMN).click()

    insertColumns()

    def export_data_excel_op():
        time.sleep(1)
        WORK_PACKAGES_SETTING_BUTTON.click()

        time.sleep(1)
        btn_export = driver.find_element(By.XPATH, vs.SETTING_BUTTON_EXPORT)
        btn_export.click()

        time.sleep(1)
        export_file_cls = driver.find_element(By.XPATH, vs.EXPORT_XLS)
        export_file_cls.click()
        time.sleep(5)
    export_data_excel_op()
    time.sleep(2)

get_input = hp.getInput()
listNameProject = get_input[0]
listLinkProject = get_input[2]

for i in range(len(listLinkProject)):
    file_exists = exists('../practice_selenium_python/export_data/' + listNameProject[i] + '/bug')
    if not file_exists:
        os.mkdir('../practice_selenium_python/export_data/' + listNameProject[i] + '/bug')
    prefs = {'download.default_directory': '/home/khuongthao/Desktop/practice_selenium_python/export_data/' + listNameProject[i] + '/bug'}
    chrome_options.add_experimental_option('prefs', prefs)
    driver = webdriver.Chrome(executable_path=vs.PATH_SELENIUM_CHORM, chrome_options=chrome_options)
    time.sleep(1)
    login('https://projects.miichisoft.net/projects/')
    time.sleep(2)
    main(listLinkProject[i], subToday)
    time.sleep(2)

