from selenium.webdriver.common.by import By
import time
from selenium import webdriver
import os
import variable as vs
from os.path import exists
import helper as hp

def login(path):
    time.sleep(2)
    driver.get(path)

    txt_email = driver.find_element(By.ID, "username")
    txt_email.send_keys(vs.USER_NAME_LOGIN)
    txt_pass = driver.find_element(By.ID, "password")
    txt_pass.send_keys(vs.PASSWORD_USER_LOGIN)

    time.sleep(1)
    btn_submit_fb = driver.find_element(By.XPATH, vs.BUTTON_LOGIN_OP)
    btn_submit_fb.submit()

def main(path):
    driver.get(path)
    time.sleep(2)
    WORK_PACKAGES = driver.find_element(By.ID, vs.ID_WORK_PACKAGE)
    WORK_PACKAGES.click()

    def filter_op():
        # FILTER
        time.sleep(2)
        button_filter = driver.find_element(By.ID, vs.ID_BUTTON_FILLTER)
        button_filter.click()

        time.sleep(2)
        filter_option_status = driver.find_element(By.ID, vs.ID_FILLTER_STATUS)
        filter_option_status.click()

        time.sleep(2)
        choose_status_all = driver.find_element(By.XPATH, vs.STATUS_OPTION_ALL)
        choose_status_all.click()

        time.sleep(2)
        add_filter_input = driver.find_element(By.XPATH, vs.INPUT_ADD_FILTER)
        add_filter_input.send_keys('type')

        time.sleep(2)
        add_filter_type = driver.find_element(By.XPATH, vs.FILTER_TYPE)
        add_filter_type.click()

        # click label type
        time.sleep(1)
        type_label = driver.find_element(By.XPATH, vs.LABEL_TYPE)
        type_label.click()

        time.sleep(1)
        driver.find_element(By.XPATH, vs.INPUT_FILTER_TYPE).send_keys('Task')

        time.sleep(1)
        choose_type_task = driver.find_element(By.XPATH, vs.OPTION_TYPE_TASK)
        choose_type_task.click()

    time.sleep(1)
    filter_op()

    WORK_PACKAGES_SETTING_BUTTON = driver.find_element(By.ID, vs.ID_WORK_PACKAGES_SETTING_BUTTON)

    def insert_column():
        # click btn setting
        time.sleep(1)
        WORK_PACKAGES_SETTING_BUTTON.click()

        time.sleep(1)
        setting_insert_column = driver.find_element(By.XPATH, vs.SETTING_INSERT_COLUMN)
        setting_insert_column.click()

        # add column accountable
        time.sleep(1)
        input_add_columns = driver.find_element(By.XPATH, vs.INPUT_ADD_COLUMN)
        input_add_columns.send_keys('Accountable')

        time.sleep(1)
        choose_column_accountable = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST)
        choose_column_accountable.click()

        # add column spent time
        time.sleep(2)
        input_add_columns.send_keys('Spent time')
        choose_column_spent_time = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST)
        choose_column_spent_time.click()
        time.sleep(1)
        # submit
        button_apply_add_columns = driver.find_element(By.XPATH, vs.BUTTON_APPLY_ADD_COLUMN)
        button_apply_add_columns.click()

    insert_column()

    def export_data_excel_op():
        time.sleep(2)
        WORK_PACKAGES_SETTING_BUTTON.click()

        time.sleep(2)
        btn_export = driver.find_element(By.XPATH, vs.SETTING_BUTTON_EXPORT)
        btn_export.click()

        time.sleep(3)
        export_file_cls = driver.find_element(By.XPATH, vs.EXPORT_XLS)
        export_file_cls.click()
        time.sleep(5)
    export_data_excel_op()
    time.sleep(2)


chrome_options = webdriver.ChromeOptions()
chrome_options.headless = True
chrome_options.add_argument('--no-sandbox')
chrome_options.add_argument('--disable-dev-shm-usage')
get_input = hp.getInput()
listNameProject = get_input[0]
listLinkProject = get_input[2]

for i in range(len(listLinkProject)):
    file_exists = exists('../practice_selenium_python/export_data/' + listNameProject[i])
    if not file_exists:
        os.mkdir('../practice_selenium_python/export_data/' + listNameProject[i])
        os.mkdir('../practice_selenium_python/export_data/' + listNameProject[i] + '/task')
    prefs = {'download.default_directory': '/home/khuongthao/Desktop/practice_selenium_python/export_data/' + listNameProject[i] + '/task'}
    chrome_options.add_experimental_option('prefs', prefs)
    driver = webdriver.Chrome(executable_path=vs.PATH_SELENIUM_CHORM, chrome_options=chrome_options)
    time.sleep(1)
    login('https://projects.miichisoft.net/projects/')
    time.sleep(2)
    main(listLinkProject[i])
    time.sleep(3)