import os

list_name = []
list_link = []
list_ggsheet = []
def getInput():
    file_input = os.listdir('../practice_selenium_python/input')
    for i in range(len(file_input)):
        with open('../practice_selenium_python/input/' + file_input[i]) as f:
            contents = f.readlines()
            for index in range(len(contents)):
                if i == 0:
                    list_ggsheet.append(contents[index].rstrip())
                if i == 1:
                    list_name.append(contents[index].rstrip())
                if i == 2:
                    list_link.append(contents[index].rstrip())

    return [list_name, list_ggsheet, list_link]