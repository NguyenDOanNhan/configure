from selenium.webdriver.common.by import By
import time
from selenium import webdriver
import os
import variable as vs
from os.path import exists
from datetime import date, timedelta
import helper as hp

chrome_options = webdriver.ChromeOptions()
chrome_options.headless = True
chrome_options.add_argument('--no-sandbox')
chrome_options.add_argument('--disable-dev-shm-usage')

today = str(date.today())
subToday = str(date.today() - timedelta(days=7))

def login(path):
    time.sleep(2)
    driver.get(path)
    txt_email = driver.find_element(By.ID, "username")
    txt_email.send_keys(vs.USER_NAME_LOGIN)
    txt_pass = driver.find_element(By.ID, "password")
    txt_pass.send_keys(vs.PASSWORD_USER_LOGIN)

    btn_submit_fb = driver.find_element(By.XPATH, vs.BUTTON_LOGIN_OP)
    btn_submit_fb.submit()

def main(path, subToday):
    time.sleep(2)
    driver.get(path)
    time.sleep(2)
    WORK_PACKAGES = driver.find_element(By.ID, vs.ID_WORK_PACKAGE)
    WORK_PACKAGES.click()
    def filter_op():
        # FILTER
        time.sleep(2)
        button_filter = driver.find_element(By.ID, vs.ID_BUTTON_FILLTER)
        button_filter.click()

        time.sleep(2)
        filter_option_status = driver.find_element(By.ID, vs.ID_FILLTER_STATUS)
        filter_option_status.click()

        # Status
        time.sleep(2)
        choose_status_all = driver.find_element(By.XPATH, vs.STATUS_OPTION_IS_NOT)
        choose_status_all.click()

        time.sleep(2)
        input_status_is_not = driver.find_element(By.XPATH, vs.INPUT_STATUS)
        input_status_is_not.send_keys('rejected')

        time.sleep(2)
        add_rejected_input_status = driver.find_element(By.XPATH, vs.OPTION_ONE)
        add_rejected_input_status.click()

        time.sleep(2)
        input_status_is_not.send_keys('on')
        add_on_hold_input_status = driver.find_element(By.XPATH, vs.ON_HOLD_INPUT_STATUS)
        add_on_hold_input_status.click()

        # Add Filter Type
        time.sleep(2)
        add_filter_input = driver.find_element(By.XPATH, vs.INPUT_ADD_FILTER)
        add_filter_input.send_keys('type')
        add_filter_input.click()

        # bug UAT
        time.sleep(2)
        add_filter_type = driver.find_element(By.XPATH, vs.FILTER_TYPE)
        add_filter_type.click()
        time.sleep(1)
        type_label = driver.find_element(By.XPATH, vs.LABEL_TYPE)
        type_label.click()

        time.sleep(1)
        driver.find_element(By.XPATH, vs.INPUT_FILTER_TYPE).send_keys('Bug UAT')
        choose_type_bug_uat = driver.find_element(By.XPATH, vs.OPTION_ONE)
        choose_type_bug_uat.click()

        # Add Filter UAT Type
        time.sleep(2)
        add_filter_uat_type = driver.find_element(By.XPATH, vs.INPUT_ADD_UAT_TYPE)
        add_filter_uat_type.send_keys('UAT')
        add_filter_uat_type.click()

        time.sleep(2)
        choose_uat_type = driver.find_element(By.XPATH, vs.OPTION_ONE)
        choose_uat_type.click()

        time.sleep(2)
        choose_status_is_not = driver.find_element(By.XPATH, vs.STATUS_OPTION_IS_NOT_UAT_TYPE)
        choose_status_is_not.click()

        time.sleep(2)
        input_add_uat_type = driver.find_element(By.XPATH, vs.INPUT_UAT_TYPE)
        input_add_uat_type.send_keys('CR')
        time.sleep(1)
        add_uat_type_cr = driver.find_element(By.XPATH, vs.OPTION_ONE)
        add_uat_type_cr.click()

        input_add_uat_type.send_keys('not')
        add_uat_type_not_bug = driver.find_element(By.XPATH, vs.OPTION_ONE)
        add_uat_type_not_bug.click()

        # Add Filter CREATED ON
        time.sleep(2)
        add_filter_created_one = driver.find_element(By.XPATH, vs.CREATED_ON)
        add_filter_created_one.send_keys('Created')
        add_filter_created_one.click()

        time.sleep(2)
        choose_created_one = driver.find_element(By.XPATH, vs.OPTION_ONE)
        choose_created_one.click()

        time.sleep(2)
        choose_status_created_on = driver.find_element(By.XPATH, vs.STATUS_OPTION_CREATED_ON)
        choose_status_created_on.click()
        time.sleep(1)
        created_on_between_start = driver.find_element(By.ID, vs.ID_BETWEEN_START).send_keys(subToday)
        created_on_between_end = driver.find_element(By.ID, vs.ID_BETWEEN_END).send_keys(today)

    filter_op()
    work_packages_setting_button = driver.find_element(By.ID, vs.ID_WORK_PACKAGES_SETTING_BUTTON)
    def insert_title_column():
        # click btn setting
        time.sleep(2)
        work_packages_setting_button.click()
        setting_insert_column = driver.find_element(By.XPATH, vs.SETTING_INSERT_COLUMN)
        setting_insert_column.click()
        # REMOVE VERSION
        time.sleep(2)
        remove_version = driver.find_element(By.XPATH, vs.REMOVE_CONFIGURATION)
        remove_version.click()
        input_add_columns = driver.find_element(By.XPATH, vs.INPUT_ADD_COLUMN)

        time.sleep(2)
        delete_option_assignee = driver.find_element(By.XPATH,
                                                     '/html/body/div[3]/ng-component/div/div/div[3]/ng-component/div/draggable-autocompleter/div/div/div[5]/a')
        delete_option_assignee.click()
        time.sleep(2)
        delete_option_status = driver.find_element(By.XPATH,
                                                   '/html/body/div[3]/ng-component/div/div/div[3]/ng-component/div/draggable-autocompleter/div/div/div[4]/a')
        delete_option_status.click()

        time.sleep(2)
        input_add_columns.send_keys('Category')
        choose_column_category = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST)
        choose_column_category.click()

        time.sleep(2)
        input_add_columns.send_keys('Status')
        add_column_status = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST).click()

        time.sleep(2)
        input_add_columns.send_keys('Assignee')
        add_column_assignee = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST).click()

        # Add Attribute Author
        time.sleep(2)
        input_add_columns.send_keys('Author')
        choose_column_accountable = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST)
        choose_column_accountable.click()

        # Add Attribute Bug Severity
        time.sleep(2)
        input_add_columns.send_keys('Bug Severity')
        choose_column_accountable = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST)
        choose_column_accountable.click()

        # Add Attribute Bug Type
        time.sleep(2)
        input_add_columns.send_keys('Bug Type')
        choose_column_accountable = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST)
        choose_column_accountable.click()

        # Add Attribute Bug Cause
        time.sleep(2)
        input_add_columns.send_keys('Bug Cause')
        choose_column_accountable = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST)
        choose_column_accountable.click()

        # Add Attribute Bug UI-Logic
        time.sleep(2)
        input_add_columns.send_keys('Bug UI-Logic')
        choose_column_accountable = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST)
        choose_column_accountable.click()

        # Add Attribute Created on
        time.sleep(2)
        input_add_columns.send_keys('Created on')
        choose_column_accountable = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST)
        choose_column_accountable.click()

        # Add Attribute Accountable
        time.sleep(2)
        input_add_columns.send_keys('Accountable')
        choose_column_accountable = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST)
        choose_column_accountable.click()

        # Add Attribute UAT Type
        time.sleep(2)
        input_add_columns.send_keys('UAT Type')
        choose_column_accountable = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST)
        choose_column_accountable.click()

        # Add Attribute Updated on
        time.sleep(2)
        input_add_columns.send_keys('Updated on')
        choose_column_accountable = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST)
        choose_column_accountable.click()

        # Add Attribute Version
        time.sleep(2)
        input_add_columns.send_keys('Version')
        choose_column_accountable = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST)
        choose_column_accountable.click()

        # Add Attribite Spent time
        time.sleep(2)
        input_add_columns.send_keys('Spent time')
        choose_column_spent_time = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST)
        choose_column_spent_time.click()

        # submit
        button_apply_add_columns = driver.find_element(By.XPATH, vs.BUTTON_APPLY_ADD_COLUMN)
        button_apply_add_columns.click()

    insert_title_column()

    def export_data_excel_op():
        time.sleep(2)
        work_packages_setting_button.click()

        time.sleep(2)
        btn_export = driver.find_element(By.XPATH, vs.SETTING_BUTTON_EXPORT)
        btn_export.click()

        time.sleep(2)
        export_file_cls = driver.find_element(By.XPATH, vs.EXPORT_XLS)
        export_file_cls.click()
        time.sleep(5)
    export_data_excel_op()
    time.sleep(2)

get_input = hp.getInput()
listNameProject = get_input[0]
listLinkProject = get_input[2]
for i in range(len(listLinkProject)):
    file_exists = exists('../practice_selenium_python/export_data/' + listNameProject[i])
    if not file_exists:
        os.mkdir('../practice_selenium_python/export_data/' + listNameProject[i])
        os.mkdir('../practice_selenium_python/export_data/' + listNameProject[i] + '/bug')
    prefs = {'download.default_directory': '/home/khuongthao/Desktop/practice_selenium_python/export_data/' + listNameProject[i] + '/bug'}
    chrome_options.add_experimental_option('prefs', prefs)
    driver = webdriver.Chrome(executable_path=vs.PATH_SELENIUM_CHORM, chrome_options=chrome_options)
    login('https://projects.miichisoft.net/projects/')
    time.sleep(2)
    main(listLinkProject[i], subToday)
    time.sleep(3)