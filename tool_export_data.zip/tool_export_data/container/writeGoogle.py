import gspread
import pandas as pd
import os
import helper as hp

sa = gspread.service_account(filename="../practice_selenium_python/credentials/service_account.json")
wks = ''

path = '../practice_selenium_python/export_data'
files = os.listdir(path)
get_input = hp.getInput()
listNameGoogle = get_input[1]
# listNameGoogle.reverse()
column_end = ''
data = ''

index_check = 0

for index1, file1 in enumerate(files):

    for j in range(len(listNameGoogle)):
            if file1 == listNameGoogle[j]:
                index_check = j
                break
    sh = sa.open(listNameGoogle[index_check])
    file_list = os.listdir(path + '/' + file1)
    for x in range(len(file_list)):
        file_name = os.listdir(path + '/' + files[x] + '/' + file_list[x])
        if x == 0:
            start = 2
            end = 0
            length = 0
            data = pd.read_excel(path + '/' + files[index1] + '/' + file_list[x] + '/' + file_name[0])
            wks = sh.worksheet("Task")
            if wks:
                column_end = 'H'
                fill_DF = data.fillna(0)
                df = pd.DataFrame(fill_DF)
                data_row = df.values.tolist()
                a = []
                for i in range(len(data)):
                    for j in range(len(df.columns.tolist()) - 1):
                        val = data_row[i][j]
                        if val == '' or val is None:
                            data_row[i][j] = 0
                    if x == 1:
                        data_row[i][11] = data_row[i][11].strftime('%Y-%m-%d %H:%M:%S.%f')
                        data_row[i][14] = data_row[i][14].strftime('%Y-%m-%d %H:%M:%S.%f')
                    a.append(data_row[i])
                length += len(a)
                end += (len(a) + 1)
                wks.update('A' + str(start) + ':' + column_end + str(end), a)
        if x == 1:
            start = 2
            end = 0
            length = 0
            for z in range(len(file_name)):
                data = pd.read_excel(path + '/' + files[x] + '/' + file_list[x] + '/' + file_name[z])
                wks = sh.worksheet("Bug list")
                if wks:
                    column_end = 'Q'

                    fill_DF = data.fillna(0)
                    df = pd.DataFrame(fill_DF)
                    data_row = df.values.tolist()
                    #
                    a = []
                    for i in range(len(data)):
                        for j in range(len(df.columns.tolist()) - 1):
                            val = data_row[i][j]
                            if val == '' or val is None:
                                data_row[i][j] = 0
                        data_row[i][11] = data_row[i][11].strftime('%Y-%m-%d %H:%M:%S.%f')
                        data_row[i][14] = data_row[i][14].strftime('%Y-%m-%d %H:%M:%S.%f')
                        a.append(data_row[i])

                    if z == 0:
                        length += len(a)
                        end += (len(a) + 1)
                    else:
                        start += length
                        length = len(a)
                        end += len(a)
                    wks.update('A' + str(start) + ':' + column_end + str(end), a)
